
import { useEffect, useState } from "react";

function Notes() {
  const [title, setTitle] = useState("");
  const [note, setNote] = useState("");
  const [notes, setNotes] = useState(() => {
    return JSON.parse(localStorage.getItem("notes")) || [];
  });
  const [editId, setEditId] = useState(null);

  useEffect(() => {
    localStorage.setItem("notes", JSON.stringify(notes));
  }, [notes]);

  function addNote(e) {
    e.preventDefault();

    if (!title.trim() || !note.trim()) return;

    setNotes([...notes, {
      id: Date.now(),
      title: title.trim(),
      note: note.trim()
    }]);

    setTitle("");
    setNote("");
  }

  function deleteNote(id) {
    setNotes(notes.filter((item) => item.id !== id));
  }

  function editNote(id, title, note) {
    if (!title.trim() || !note.trim()) return;

    setNotes(notes.map((item) =>
      item.id === id
        ? { ...item, title: title.trim(), note: note.trim() }
        : item
    ));

    setEditId(null);
  }

  return (
    <main className="notes-app">
      <header>
        <h1>My Notes</h1>
        <p>Save your thoughts in one place.</p>
      </header>

      <form className="note-form" onSubmit={addNote}>
        <input
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          placeholder="Note title"
          required
        />

        <textarea
          value={note}
          onChange={(e) => setNote(e.target.value)}
          placeholder="Write your note..."
          rows="4"
          required
        />

        <button>Add Note</button>
      </form>

      <section className="notes-list">
        {notes.map((item) => (
          <article className="note-card" key={item.id}>
            {editId === item.id ? (
              <form
                className="edit-note"
                onSubmit={(e) => {
                  e.preventDefault();
                  editNote(
                    item.id,
                    e.target.elements.title.value,
                    e.target.elements.note.value
                  );
                }}
              >
                <input name="title" defaultValue={item.title} required />
                <textarea name="note" defaultValue={item.note} rows="4" required />
                <button>Save</button>
                <button type="button" onClick={() => setEditId(null)}>
                  Cancel
                </button>
              </form>
            ) : (
              <>
                <h3>{item.title}</h3>
                <p>{item.note}</p>
                <div className="note-actions">
                  <button type="button" onClick={() => setEditId(item.id)}>
                    Edit
                  </button>
                  <button type="button" onClick={() => deleteNote(item.id)}>
                    Delete
                  </button>
                </div>
              </>
            )}
          </article>
        ))}
      </section>

      {notes.length === 0 && (
        <p className="empty">No notes yet. Create your first note!</p>
      )}
    </main>
  );
}

export default Notes;
