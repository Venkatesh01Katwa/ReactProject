
import { useEffect, useState } from "react";
import "./App.css";

function App() {
  const [task, setTask] = useState("");
  const [tasks, setTasks] = useState(() => {
    return JSON.parse(localStorage.getItem("tasks")) || [];
  });
  const [filter, setFilter] = useState("All");
  const [editId, setEditId] = useState(null);

  useEffect(() => {
    localStorage.setItem("tasks", JSON.stringify(tasks));
  }, [tasks]);

  function addTask(e) {
    e.preventDefault();

    if (!task.trim()) return;

    setTasks([...tasks, {
      id: Date.now(),
      name: task.trim(),
      completed: false
    }]);

    setTask("");
  }

  function deleteTask(id) {
    setTasks(tasks.filter((item) => item.id !== id));
  }

  function toggleTask(id) {
    setTasks(tasks.map((item) =>
      item.id === id
        ? { ...item, completed: !item.completed }
        : item
    ));
  }

  function editTask(id, name) {
    if (!name.trim()) return;

    setTasks(tasks.map((item) =>
      item.id === id ? { ...item, name: name.trim() } : item
    ));

    setEditId(null);
  }

  const filteredTasks = tasks.filter((item) => {
    if (filter === "Completed") return item.completed;
    if (filter === "Pending") return !item.completed;
    return true;
  });

  return (
    <main className="app">
      <header>
        <h1>My Tasks</h1>
        <p>A little progress every day.</p>
      </header>

      <div className="summary">
        <div><strong>{tasks.length}</strong><span>Total</span></div>
        <div><strong>{tasks.filter((item) => !item.completed).length}</strong><span>Pending</span></div>
        <div><strong>{tasks.filter((item) => item.completed).length}</strong><span>Completed</span></div>
      </div>

      <form className="task-form" onSubmit={addTask}>
        <input
          value={task}
          onChange={(e) => setTask(e.target.value)}
          placeholder="What do you need to do?"
        />
        <button>Add Task</button>
      </form>

      <nav className="filters">
        {["All", "Pending", "Completed"].map((item) => (
          <button
            type="button"
            key={item}
            className={filter === item ? "active" : ""}
            onClick={() => setFilter(item)}
          >
            {item}
          </button>
        ))}
      </nav>

      <ul className="task-list">
        {filteredTasks.map((item) => (
          <li key={item.id}>
            <input
              type="checkbox"
              checked={item.completed}
              onChange={() => toggleTask(item.id)}
            />

            {editId === item.id ? (
              <form
                className="edit-form"
                onSubmit={(e) => {
                  e.preventDefault();
                  editTask(item.id, e.target.elements.taskName.value);
                }}
              >
                <input name="taskName" defaultValue={item.name} autoFocus />
                <button>Save</button>
              </form>
            ) : (
              <>
                <div className="task-info">
                  <span className={item.completed ? "done" : ""}>{item.name}</span>
                  <small>{item.completed ? "Completed" : "Pending"}</small>
                </div>
                <div className="actions">
                  <button type="button" onClick={() => setEditId(item.id)}>Edit</button>
                  <button type="button" onClick={() => deleteTask(item.id)}>Delete</button>
                </div>
              </>
            )}
          </li>
        ))}
      </ul>

      {filteredTasks.length === 0 && (
        <p className="empty">No tasks here. Add one to get started!</p>
      )}
    </main>
  );
}

export default App;
